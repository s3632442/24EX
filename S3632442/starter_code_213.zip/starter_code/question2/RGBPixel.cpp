#include <exception>
#include <stdexcept>
#include "RGBPixel.h"

